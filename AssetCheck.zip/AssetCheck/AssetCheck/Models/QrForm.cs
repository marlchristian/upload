﻿namespace AssetCheck.Models
{
    public class QrForm
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Location { get; set; }
        public string Area { get; set; }
        public string? Bay { get; set; }
        public string? Station { get; set; }
        public List<string> Asset { get; set; } = new();
        public DateTime Timestamp { get; set; } = DateTime.UtcNow;
    }
}
