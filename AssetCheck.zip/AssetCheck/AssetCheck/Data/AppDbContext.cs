﻿using Microsoft.EntityFrameworkCore;
using AssetCheck.Models;

namespace AssetCheck.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<QrForm> QrForms { get; set; }
    }
}
