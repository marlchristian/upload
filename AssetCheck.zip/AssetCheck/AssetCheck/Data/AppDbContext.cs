﻿using Microsoft.EntityFrameworkCore;
using AssetCheck.Models;
using System.Text.Json;
using Microsoft.EntityFrameworkCore.ChangeTracking;

namespace AssetCheck.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        {
        }

        public DbSet<QrForm> QrForms { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Configure Assets to be stored as JSON in a string column
            modelBuilder.Entity<QrForm>()
                .Property(e => e.Asset)
                .HasColumnName("Asset") // 👈 Map it to the existing column
                .HasConversion(
                v => JsonSerializer.Serialize(v, new JsonSerializerOptions()),
                v => JsonSerializer.Deserialize<List<string>>(v, new JsonSerializerOptions()) ?? new List<string>()
                )
                .Metadata.SetValueComparer(new ValueComparer<List<string>>(
                    (c1, c2) => c1.SequenceEqual(c2),
                    c => c.Aggregate(0, (a, v) => HashCode.Combine(a, v.GetHashCode())),
                    c => c.ToList()));
        }
    }
}
