﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using AssetCheck.Data;
using AssetCheck.Models;

namespace AssetCheck.Controllers
{
    public class QrFormsController : Controller
    {
        private readonly AppDbContext _context;

        public QrFormsController(AppDbContext context)
        {
            _context = context;
        }

        // GET: QrForms
        public async Task<IActionResult> Index()
        {
            var forms = await _context.QrForms.ToListAsync();
            return View(forms);
        }

        // GET: QrForms/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: QrForms/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(QrForm form)
        {
            if (ModelState.IsValid)
            {
                _context.Add(form);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(form);
        }

        // GET: QrForms/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
                return NotFound();

            var form = await _context.QrForms
                .FirstOrDefaultAsync(m => m.Id == id);

            if (form == null)
                return NotFound();

            return View(form);
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.QrForms == null)
            {
                return NotFound();
            }

            var qrForm = await _context.QrForms.FindAsync(id);
            if (qrForm == null)
            {
                return NotFound();
            }
            return View(qrForm);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, QrForm form)
        {
            if (id != form.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(form);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!QrFormExists(form.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }

            return View(form);
        }

        // GET: QrForms/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
                return NotFound();

            var form = await _context.QrForms
                .FirstOrDefaultAsync(m => m.Id == id);

            if (form == null)
                return NotFound();

            return View(form);
        }

        // POST: QrForms/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var form = await _context.QrForms.FindAsync(id);
            if (form != null)
            {
                _context.QrForms.Remove(form);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }

        private bool QrFormExists(int id)
        {
            return _context.QrForms.Any(e => e.Id == id);
        }
    }
}